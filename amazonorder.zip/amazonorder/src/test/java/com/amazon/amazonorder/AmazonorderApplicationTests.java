package com.amazon.amazonorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonorderApplicationTests {

	@Test
	void contextLoads() {
	}

}
